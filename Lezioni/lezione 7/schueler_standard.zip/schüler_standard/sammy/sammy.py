# ============================================================
#  MEIN HAUS — ein Haus in einem Zug gezeichnet
#
#  Die Schildkröte läuft einmal um das ganze Haus herum.
#  Ändere "seite" und das ganze Haus wird größer oder kleiner.
# ============================================================

from turtle import *

speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

seite = 100        # <-- wie groß das Haus ist
tuer_abstand = 30  # <-- wie weit die Tür von der linken Ecke entfernt ist
tuer_breite = 20   # <-- wie breit die Tür ist
tuer_hoehe = 40    # <-- wie hoch die Tür ist
start_x = -50      # <-- wo das Haus steht: links / rechts
start_y = -100     # <-- wo das Haus steht: unten / oben

# ============================================================

# --- An den Start ---
penup()
goto(start_x, start_y)
pendown()
setheading(0)

# --- Das Haus ---
# Alle Drehungen zusammen: 90 + 30 + 120 + 30 + 90 = 360 Grad.
# Dann ist die Schildkröte wieder am Start und das Haus ist zu.
forward(seite)     # Boden
left(90)
forward(seite)     # rechte Wand
left(30)
forward(seite)     # rechte Dachseite
left(120)
forward(seite)     # linke Dachseite
left(30)
forward(seite)     # linke Wand
left(90)

# --- Die Tür ---
# Ein Stück am Boden entlang, dann hoch, quer, runter.
forward(tuer_abstand)
left(90)
forward(tuer_hoehe)
right(90)
forward(tuer_breite)
right(90)
forward(tuer_hoehe)

hideturtle()  # Pfeil ausblenden
done()
