# ============================================================
#  HAUS MIT PYTHAGORAS
#
#  Das Dach ist ein Dreieck mit einem rechten Winkel oben.
#  Python rechnet die Breite des Hauses selbst aus.
# ============================================================

from turtle import *
import math

speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen
pensize(10)

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

hoehe = 200        # <-- wie hoch die Wände sind
dach = 200         # <-- Länge einer Dachkante
zeichnen = True    # <-- True = Haus zeichnen, False = nichts zeichnen

# ============================================================

# Pythagoras: Breite² = dach² + dach²   (das Dach hat oben 90 Grad)
breite = math.sqrt(dach ** 2 + dach ** 2)

# --- An den Start ---
# Rechte untere Ecke. Von dort geht es gegen den Uhrzeigersinn.
penup()
goto(breite / 2, -hoehe / 2)
setheading(0)

# --- Das Haus ---
if zeichnen:
    pendown()
    left(90)
    forward(hoehe)       # rechte Wand
    left(45)
    forward(dach)        # rechte Dachseite
    left(90)
    forward(dach)        # linke Dachseite
    left(45)
    forward(hoehe)       # linke Wand
    left(90)
    forward(breite)      # Boden

# ============================================================
#  IDEEN FÜR DICH
#  1) Tür und Fenster: Maße aus hoehe und breite ausrechnen.
#  2) Dach mit goto zur Spitze statt mit Winkeln: dann geht jede Dachhöhe.
#  3) Ein Dorf: mehrere Häuser mit for und einem Abstand.
# ============================================================

hideturtle()  # Pfeil ausblenden
done()
