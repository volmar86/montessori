# ============================================================
#  WÜRFEL IM SCHRÄGBILD
#
#  Vorne ein Quadrat, hinten ein Quadrat, dazwischen 4 Kanten.
#  Das ist Kavalierperspektive: 45 Grad, Tiefe halbiert.
# ============================================================

from turtle import *
import math

speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

seite = 200        # <-- Kantenlänge der Vorderseite
tiefe = seite / 2  # <-- Länge der Kanten nach hinten (Schrägbild: halbe Seite)
start_x = -100     # <-- linke untere Ecke: links / rechts
start_y = -100     # <-- linke untere Ecke: unten / oben

# ============================================================

# So weit liegt die Rückseite rechts und oben (Pythagoras: bei 45 Grad gleich viel).
versatz = tiefe / math.sqrt(2)

# --- Vorderseite und Kanten nach hinten ---
# An jeder Ecke: kurz nach hinten (45 Grad) und wieder zurück.
penup()
goto(start_x, start_y)
pendown()
setheading(0)
for i in range(4):
    forward(seite)
    richtung = heading()      # merken, wohin die Schildkröte schaut
    setheading(45)
    forward(tiefe)
    backward(tiefe)
    setheading(richtung)
    left(90)

# --- Rückseite ---
penup()
goto(start_x + versatz, start_y + versatz)
pendown()
for i in range(4):
    forward(seite)
    left(90)

# ============================================================
#  IDEEN FÜR DICH
#  1) Die 3 hinteren Kanten gestrichelt zeichnen (for + penup/pendown).
#  2) Quader statt Würfel: breite, hoehe und tiefe einzeln einstellen.
#  3) Danach: ein Haus im Schrägbild (Quader + Dach).
# ============================================================

hideturtle()  # Pfeil ausblenden
done()
