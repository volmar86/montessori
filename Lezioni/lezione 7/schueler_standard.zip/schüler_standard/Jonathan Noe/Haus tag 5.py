# ============================================================
#  MEIN HAUS (Tag 5) — ein Umriss in einem Zug
#
#  Erst drehen, dann laufen: jede Zeile ist eine Kante.
#  Ändere "groesse" und alles wird größer oder kleiner.
# ============================================================

from turtle import *

speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen
pensize(6)

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

groesse = 1        # <-- 1 = normal, 2 = doppelt so groß, 0.5 = halb so groß
start_x = -120     # <-- wo es anfängt: links / rechts
start_y = -50      # <-- wo es anfängt: unten / oben

# ============================================================

# --- An den Start ---
penup()
goto(start_x, start_y)
pendown()
setheading(0)

# --- Der Umriss ---
# Jede Länge wird mit "groesse" mal genommen.
left(45)
forward(45 * groesse)
right(45)
left(30)
forward(200 * groesse)
right(90)
forward(99 * groesse)
right(50)
forward(70 * groesse)
right(45)
forward(45 * groesse)
right(60)
forward(110 * groesse)
left(45)
forward(60 * groesse)
left(30)
forward(37 * groesse)
setheading(130)    # setheading = ganz genau in diese Richtung schauen
forward(17 * groesse)

# --- Noch ein Strich (ohne Verbindung) ---
# penup = nicht zeichnen, goto = springe zu diesem Punkt.
penup()
goto(start_x + 130 * groesse, start_y + 20 * groesse)
forward(23 * groesse)
left(190)
pendown()
forward(45 * groesse)

hideturtle()  # Pfeil ausblenden
done()
