# ============================================================
#  ZAUN — Latten auf einer Querstange
#
#  Eine Latte wird einmal beschrieben und dann oft wiederholt.
#  Ändere "anzahl" für einen längeren oder kürzeren Zaun.
# ============================================================

from turtle import *

setup(1.0, 0.6)   # das Fenster so breit wie der Bildschirm
speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

anzahl = 37        # <-- wie viele Latten (zu breit? dann weniger)
abstand = 40       # <-- von einer Latte zur nächsten
latte_hoehe = 115  # <-- gerader Teil der Latte
spitze = 15        # <-- Länge der schrägen Kanten oben
latte_breite = 21  # <-- wie breit eine Latte ist
boden_y = -60      # <-- wo die Latten unten stehen

stange_hoehe = 20  # <-- wie dick die Querstange ist
stange_y = 30      # <-- Abstand der Stange vom Boden
ueberstand = 15    # <-- so weit ragt die Stange links und rechts heraus

farbe = "sienna"   # <-- Holzfarbe

# ============================================================

# So breit ist der Zaun. Damit steht er genau in der Mitte.
zaun_breite = (anzahl - 1) * abstand + latte_breite
start_x = -zaun_breite / 2

color("black", farbe)

# --- Die Querstange ---
# Ein Rechteck: zwei Mal "lange Seite, kurze Seite".
penup()
goto(start_x - ueberstand, boden_y + stange_y)
pendown()
setheading(0)
begin_fill()
for i in range(2):
    forward(zaun_breite + 2 * ueberstand)
    left(90)
    forward(stange_hoehe)
    left(90)
end_fill()

# --- Die Latten ---
# Jede Runde der Schleife zeichnet eine Latte, ein Stück weiter rechts.
for nummer in range(anzahl):
    penup()
    goto(start_x + nummer * abstand, boden_y)
    pendown()
    setheading(90)
    begin_fill()
    forward(latte_hoehe)
    right(45)
    forward(spitze)        # Spitze: links hoch ...
    right(90)
    forward(spitze)        # ... und rechts wieder runter
    right(45)
    forward(latte_hoehe)
    right(90)
    forward(latte_breite)
    end_fill()

hideturtle()
done()
