# ============================================================
#  HAUS MIT FENSTER UND TÜR
#
#  Wände, Dach, ein Fenster mit Gitter und eine Tür.
#  Ändere die Zahlen oben und drück Play.
# ============================================================

from turtle import *

speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

breite = 265       # <-- wie breit das Haus ist
hoehe = 130        # <-- wie hoch die Wände sind
dach_hoehe = 60    # <-- wie hoch das Dach ist
dach_oben = 150    # <-- wie breit das Dach oben ist
start_x = -130     # <-- wo das Haus steht: links / rechts
start_y = -100     # <-- wo das Haus steht: unten / oben

fenster_breite = 70   # <-- wie breit das Fenster ist
fenster_hoehe = 50    # <-- wie hoch das Fenster ist
fenster_abstand = 37  # <-- Abstand von der linken Wand
fenster_y = 45        # <-- Abstand vom Boden

tuer_breite = 50      # <-- wie breit die Tür ist
tuer_hoehe = 100      # <-- wie hoch die Tür ist
tuer_abstand = 157    # <-- Abstand von der linken Wand

# ============================================================

# --- Die Wände ---
# Ein Rechteck: zwei Mal "lange Seite, kurze Seite".
penup()
goto(start_x, start_y)
pendown()
setheading(0)
for i in range(2):
    forward(breite)
    left(90)
    forward(hoehe)
    left(90)

# --- Das Dach ---
# Ein Trapez: unten breit, oben schmal.
dach_rand = (breite - dach_oben) / 2     # so weit rückt das Dach nach innen
penup()
goto(start_x, start_y + hoehe)
pendown()
goto(start_x + dach_rand, start_y + hoehe + dach_hoehe)
goto(start_x + breite - dach_rand, start_y + hoehe + dach_hoehe)
goto(start_x + breite, start_y + hoehe)

# --- Das Fenster ---
penup()
goto(start_x + fenster_abstand, start_y + fenster_y)
pendown()
setheading(0)
for i in range(2):
    forward(fenster_breite)
    left(90)
    forward(fenster_hoehe)
    left(90)

# --- Das Fenstergitter ---
# Ein Strich waagrecht und einer senkrecht, genau in der Mitte.
penup()
goto(start_x + fenster_abstand, start_y + fenster_y + fenster_hoehe / 2)
pendown()
forward(fenster_breite)
penup()
goto(start_x + fenster_abstand + fenster_breite / 2, start_y + fenster_y)
pendown()
setheading(90)
forward(fenster_hoehe)

# --- Die Tür ---
penup()
goto(start_x + tuer_abstand, start_y)
pendown()
setheading(90)
for i in range(2):
    forward(tuer_hoehe)
    right(90)
    forward(tuer_breite)
    right(90)

# --- Die Türklinke ---
penup()
goto(start_x + tuer_abstand, start_y + 52)
pendown()
setheading(0)
forward(20)

hideturtle()  # Pfeil ausblenden
done()
