# ============================================================
#  HAUS MIT SCHEUNE AUF EINEM HÜGEL
#
#  Was zuerst gezeichnet wird, liegt hinten. Zuerst der Hügel,
#  dann das Haus, ganz zum Schluss die Scheune (liegt vorne).
# ============================================================

from turtle import *

setup(900, 650)
bgcolor("lightskyblue")
speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

groesse = 50           # <-- wie groß ein Gebäudeteil ist (alles hängt daran)
start_x = -50          # <-- Scheune, linke untere Ecke: links / rechts
start_y = -50          # <-- Scheune, linke untere Ecke: unten / oben

huegel_radius = 350    # <-- wie breit der Hügel ist
huegel_y = -325        # <-- Boden vom Hügel (unterer Rand vom Fenster)

farbe_huegel = "forestgreen"
farbe_dach = "red"
farbe_wand = "wheat"

# ============================================================

dach_hoehe = groesse * 0.87     # Dreieck mit gleich langen Seiten

# --- Der Hügel ---
# Zum Ausmalen: begin_fill() vor dem Bogen, end_fill() danach.
# Minus beim Radius = der Bogen geht nach rechts herum (über die Mitte).
color("black", farbe_huegel)
penup()
goto(-huegel_radius, huegel_y)
pendown()
setheading(90)
begin_fill()
circle(-huegel_radius, 180)
end_fill()

# --- Das Haus: Vorderwand ---
# Wände werden ausgemalt, sonst scheint der Hügel durch.
haus_x = start_x - groesse             # das Haus steht links von der Scheune
haus_y = start_y + 0.6 * groesse
haus_hoehe = 1.4 * groesse
color("black", farbe_wand)
penup()
goto(haus_x, haus_y)
pendown()
setheading(0)
begin_fill()
for i in range(2):
    forward(groesse)
    left(90)
    forward(haus_hoehe)
    left(90)
end_fill()

# --- Das Haus: Seitenwand ---
penup()
goto(haus_x + groesse, haus_y)
pendown()
begin_fill()
for i in range(2):
    forward(groesse)
    left(90)
    forward(haus_hoehe)
    left(90)
end_fill()

# --- Das Haus: Dach ---
# Vorne ein Dreieck, an der Seite eine schräge Fläche.
haus_oben = haus_y + haus_hoehe
color("black", farbe_dach)
penup()
goto(haus_x, haus_oben)
pendown()
begin_fill()
goto(haus_x + groesse / 2, haus_oben + dach_hoehe)
goto(haus_x + groesse, haus_oben)
end_fill()
penup()
goto(haus_x + groesse, haus_oben)
pendown()
begin_fill()
goto(haus_x + 2 * groesse, haus_oben)
goto(haus_x + 1.5 * groesse, haus_oben + dach_hoehe)
goto(haus_x + 0.5 * groesse, haus_oben + dach_hoehe)
goto(haus_x + groesse, haus_oben)
end_fill()

# --- Die Scheune: Wände ---
# Vorderwand (ein Quadrat) und Seitenwand (doppelt so lang).
color("black", farbe_wand)
penup()
goto(start_x, start_y)
pendown()
setheading(0)
begin_fill()
for i in range(2):
    forward(groesse)
    left(90)
    forward(groesse)
    left(90)
end_fill()
penup()
goto(start_x + groesse, start_y)
pendown()
begin_fill()
for i in range(2):
    forward(2 * groesse)
    left(90)
    forward(groesse)
    left(90)
end_fill()

# --- Die Scheune: Dach ---
scheune_oben = start_y + groesse
color("black", farbe_dach)
penup()
goto(start_x, scheune_oben)
pendown()
begin_fill()
goto(start_x + groesse / 2, scheune_oben + dach_hoehe)
goto(start_x + groesse, scheune_oben)
end_fill()
penup()
goto(start_x + groesse, scheune_oben)
pendown()
begin_fill()
goto(start_x + 3 * groesse, scheune_oben)
goto(start_x + 2.5 * groesse, scheune_oben + dach_hoehe)
goto(start_x + 0.5 * groesse, scheune_oben + dach_hoehe)
goto(start_x + groesse, scheune_oben)
end_fill()

hideturtle()
done()
