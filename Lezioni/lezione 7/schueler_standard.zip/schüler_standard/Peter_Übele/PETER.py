# ============================================================
#  HUNDEHÜTTE UND BAUM
#
#  Die Baumkrone besteht aus Halbkreisen.
#  Ändere die Zahlen oben und schau, was passiert.
# ============================================================

from turtle import *

setup(1200, 700)
speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

boden_y = -300        # <-- der Boden: hier stehen Hütte und Baum

huette_x = -310       # <-- linke Ecke der Hütte
huette_breite = 160   # <-- wie breit die Hütte ist
wand_hoehe = 130      # <-- wie hoch die Wände sind
tuer_radius = 50      # <-- wie groß die runde Tür ist
tuer_hoehe = 60       # <-- gerader Teil der Tür, bis der Bogen anfängt

stamm_x = 0           # <-- linke Seite vom Stamm
stamm_breite = 50     # <-- wie dick der Stamm ist
stamm_hoehe = 300     # <-- wie hoch der Stamm ist

kronen_radius = 60    # <-- wie groß die Halbkreise sind
lappen = 8            # <-- wie viele Halbkreise die Krone hat

# ============================================================

# --- Die Hütte ---
# Wände und Dach: von Punkt zu Punkt.
rand = (huette_breite - 2 * tuer_radius) / 2    # Boden links und rechts neben der Tür
penup()
goto(huette_x, boden_y)
pendown()
goto(huette_x, boden_y + wand_hoehe)                                          # linke Wand
goto(huette_x + huette_breite / 2, boden_y + wand_hoehe + huette_breite / 2)  # Dach hoch
goto(huette_x + huette_breite, boden_y + wand_hoehe)                          # Dach runter
goto(huette_x + huette_breite, boden_y)                                       # rechte Wand
goto(huette_x + huette_breite - rand, boden_y)                                # Boden rechts

# --- Die Tür ---
# Gerade hoch, dann ein Halbkreis nach links, dann gerade runter.
setheading(90)
forward(tuer_hoehe)
circle(tuer_radius, 180)
forward(tuer_hoehe)
goto(huette_x, boden_y)                         # Boden links

# --- Der Stamm ---
stamm_oben = boden_y + stamm_hoehe
penup()
goto(stamm_x, stamm_oben)
pendown()
goto(stamm_x, boden_y)
goto(stamm_x + stamm_breite, boden_y)
goto(stamm_x + stamm_breite, stamm_oben)

# --- Die Krone: Startpunkt ---
# Die Mitte der Krone liegt über dem Stamm. Von dort rechnen wir den Start aus.
kronen_x = stamm_x + stamm_breite / 2
kronen_y = stamm_oben + 2.3 * kronen_radius
color("green")
penup()
goto(kronen_x + kronen_radius, kronen_y - 2.4 * kronen_radius)
pendown()

# --- Die Krone: Halbkreise ---
# Halbkreis = circle(radius, 180). Dann drehen, nächster Halbkreis.
# 8 mal 135 Grad = 1080 Grad = 3 volle Drehungen. Darum schließt sich die Form.
drehung = 180 - 360 / lappen      # bei 8 Halbkreisen: 135. Probier lappen = 6 oder 10!
setheading(-360 / lappen)
begin_fill()
for i in range(lappen):
    circle(kronen_radius, 180)
    right(drehung)
end_fill()

hideturtle()  # Pfeil ausblenden
done()
