# ============================================================
#  HAUS MIT SONNE
#
#  Haus, Tür, zwei Fenster und eine Sonne mit Strahlen.
#  Ändere die Zahlen oben und drück Play.
# ============================================================

from turtle import *

speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

breite = 200       # <-- wie breit das Haus ist
hoehe = 150        # <-- wie hoch die Wände sind
dach_hoehe = 120   # <-- wie hoch das Dach ist
start_x = -100     # <-- wo das Haus steht: links / rechts
start_y = -100     # <-- wo das Haus steht: unten / oben

tuer_breite = 50   # <-- wie breit die Tür ist
tuer_hoehe = 75    # <-- wie hoch die Tür ist
fenster = 40       # <-- wie groß ein Fenster ist (ein Quadrat)
fenster_rand = 15  # <-- Abstand zwischen Tür und Fenster
fenster_y = 60     # <-- wie weit oben die Fenster sitzen

sonne_x = -270     # <-- Mitte der Sonne: links / rechts
sonne_y = 220      # <-- Mitte der Sonne: unten / oben
sonne_radius = 50  # <-- wie groß die Sonne ist
strahlen = 8       # <-- wie viele Strahlen
strahl_laenge = 60 # <-- wie lang ein Strahl ist

# ============================================================

# --- Die Wände ---
# Ein Rechteck: zwei Mal "lange Seite, kurze Seite".
penup()
goto(start_x, start_y)
pendown()
setheading(0)
for i in range(2):
    forward(breite)
    left(90)
    forward(hoehe)
    left(90)

# --- Das Dach ---
# Von der linken Ecke zur Spitze und runter zur rechten Ecke.
penup()
goto(start_x, start_y + hoehe)
pendown()
goto(start_x + breite / 2, start_y + hoehe + dach_hoehe)
goto(start_x + breite, start_y + hoehe)

# --- Die Tür ---
tuer_x = start_x + (breite - tuer_breite) / 2     # die Tür steht in der Mitte
penup()
goto(tuer_x, start_y)
pendown()
setheading(90)
forward(tuer_hoehe)
right(90)
forward(tuer_breite)
right(90)
forward(tuer_hoehe)

# --- Die Türklinke ---
penup()
goto(tuer_x, start_y + 30)
pendown()
setheading(0)
forward(13)
right(90)
forward(8)

# --- Fenster links ---
fenster_x = tuer_x - fenster_rand - fenster
penup()
goto(fenster_x, start_y + fenster_y)
pendown()
setheading(0)
for i in range(4):
    forward(fenster)
    left(90)
penup()
goto(fenster_x + fenster / 2, start_y + fenster_y)     # Kreuz: senkrecht
pendown()
setheading(90)
forward(fenster)
penup()
goto(fenster_x, start_y + fenster_y + fenster / 2)     # Kreuz: waagrecht
pendown()
setheading(0)
forward(fenster)

# --- Fenster rechts ---
fenster_x = tuer_x + tuer_breite + fenster_rand
penup()
goto(fenster_x, start_y + fenster_y)
pendown()
setheading(0)
for i in range(4):
    forward(fenster)
    left(90)
penup()
goto(fenster_x + fenster / 2, start_y + fenster_y)
pendown()
setheading(90)
forward(fenster)
penup()
goto(fenster_x, start_y + fenster_y + fenster / 2)
pendown()
setheading(0)
forward(fenster)

# --- Die Sonne ---
# circle() startet unten: darum eine Radiuslänge tiefer anfangen.
penup()
goto(sonne_x, sonne_y - sonne_radius)
pendown()
setheading(0)
circle(sonne_radius)

# --- Die Strahlen ---
# Jeder Strahl dreht sich um 360 geteilt durch die Anzahl weiter.
for i in range(strahlen):
    penup()
    goto(sonne_x, sonne_y)
    setheading(i * 360 / strahlen)
    forward(sonne_radius + 15)
    pendown()
    forward(strahl_laenge)

hideturtle()  # Pfeil ausblenden
done()
