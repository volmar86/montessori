# ============================================================
#  DREI KREISE — blau, dick, übereinander
#
#  Jeder Kreis steht auf dem Kreis darunter.
#  Ändere die Radien oder die Dicke des Stifts.
# ============================================================

from turtle import *

speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

radius_oben = 50     # <-- wie groß der obere Kreis ist
radius_mitte = 70    # <-- wie groß der mittlere Kreis ist
radius_unten = 90    # <-- wie groß der untere Kreis ist
dicke = 50           # <-- wie dick der Stift ist
farbe = "blue"       # <-- die Farbe
start_x = 0          # <-- wo die Kreise stehen: links / rechts
start_y = 110        # <-- der tiefste Punkt vom oberen Kreis

# ============================================================

pensize(dicke)
color(farbe)

# --- Der obere Kreis ---
# circle() fängt immer unten am Kreis an.
penup()
goto(start_x, start_y)
pendown()
begin_fill()
circle(radius_oben)
end_fill()

# --- Der mittlere Kreis ---
# Er fängt einen Durchmesser (2 mal Radius) tiefer an.
mitte_y = start_y - 2 * radius_mitte
penup()
goto(start_x, mitte_y)
pendown()
begin_fill()
circle(radius_mitte)
end_fill()

# --- Der untere Kreis ---
unten_y = mitte_y - 2 * radius_unten
penup()
goto(start_x, unten_y)
pendown()
begin_fill()
circle(radius_unten)
end_fill()

hideturtle()  # Pfeil ausblenden
done()
