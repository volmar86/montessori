# ============================================================
#  MEIN NAME — SANDRA in Pink
#
#  Jeder Buchstabe fängt bei "x" an und ist "hoehe" hoch.
#  Ändere die Zahlen oben, zum Beispiel die Farbe.
# ============================================================

from turtle import *

speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

hoehe = 100          # <-- wie hoch die Buchstaben sind
abstand = 25         # <-- Lücke zwischen den Buchstaben
dicke = 8            # <-- wie dick der Stift ist
farbe = "hotpink"    # <-- Pink: "pink", "hotpink" oder "deeppink"
start_x = -210       # <-- wo der Name anfängt: links / rechts
start_y = -50        # <-- wo der Name steht: unten / oben

# ============================================================

breite = hoehe / 2        # jeder Buchstabe ist halb so breit wie hoch
r = hoehe / 4             # Radius für die Rundungen
schritt = breite + abstand   # so weit rückt der nächste Buchstabe

pensize(dicke)
color(farbe)

x = start_x               # x = wo der aktuelle Buchstabe anfängt
y = start_y

# --- S ---
# circle(r, 270) = Kreisbogen. Plus = links herum, minus = rechts herum.
penup()
goto(x + 2 * r, y + 3 * r)
pendown()
setheading(90)
circle(r, 270)
circle(-r, 270)
x = x + schritt

# --- A ---
# Zwei Beine und ein Querstrich in der Mitte.
penup()
goto(x, y)
pendown()
goto(x + breite / 2, y + hoehe)
goto(x + breite, y)
penup()
goto(x + breite / 4, y + hoehe / 2)
pendown()
goto(x + 3 * breite / 4, y + hoehe / 2)
x = x + schritt

# --- N ---
penup()
goto(x, y)
pendown()
goto(x, y + hoehe)
goto(x + breite, y)
goto(x + breite, y + hoehe)
x = x + schritt

# --- D ---
# Ein Halbkreis nach rechts und dann die gerade Linie zurück.
penup()
goto(x, y + hoehe)
pendown()
setheading(0)
circle(-hoehe / 2, 180)
goto(x, y + hoehe)
x = x + schritt

# --- R ---
# Gerade Linie, oben ein kleiner Bogen, dann das Bein.
penup()
goto(x, y)
pendown()
goto(x, y + hoehe)
setheading(0)
forward(breite - r)
circle(-r, 180)
forward(breite - r)
goto(x + breite, y)
x = x + schritt

# --- A ---
penup()
goto(x, y)
pendown()
goto(x + breite / 2, y + hoehe)
goto(x + breite, y)
penup()
goto(x + breite / 4, y + hoehe / 2)
pendown()
goto(x + 3 * breite / 4, y + hoehe / 2)

hideturtle()  # Pfeil ausblenden
done()
