from turtle import *

# start punkt
start_x = 0
start_y = -300
setup(1200,700)
penup()
goto(start_x,start_y)
pendown()
penup()
forward(-150)
pendown()
#Hundehütte
left(180)
forward(30)
right(90)
forward(60)
circle(50,180)
forward(60)
right(90)
forward(30)
right(90)
forward(130)
right(45)
#Dach
forward(110)
right(90)
forward(115)
right(45)
forward(127)
#Baumstamm
penup()
goto(0,-300)
pendown()
left(180)
forward (300)
penup()
goto(50,-300)
pendown()
forward(300)
penup()
goto(0,-300)
pendown()
right(90)
forward(50)
penup()
goto(85,-3)
#Blätter
pendown()
setheading(0)
right(45)
color("Green","Green")
begin_fill()
for i in range(8):
    circle(60,180)
    right(135)
end_fill()



done()
