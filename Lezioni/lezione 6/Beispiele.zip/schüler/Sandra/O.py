from turtle import *
forward(30)
right(90)
forward(60)
right(90)
forward(30)
right(90)
forward(60)
done()
