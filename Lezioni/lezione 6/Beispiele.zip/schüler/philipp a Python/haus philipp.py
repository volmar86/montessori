from turtle import*
import math
# Geschwindeichgeit

speed(20)

# wand breite

pensize(10)

# hoehe

hoehe = 200

# dach lange

dach = 200






















































































































































breite = math.sqrt(dach**2 + dach**2)
a=0
#if a == 0:
penup()
goto(breite/2,-hoehe/2)
if a == 0:
    pendown()
    left(90)
    forward(hoehe)
    left(45)
    forward(dach)
    left(90)
    forward(dach)
    left(45)
    forward(hoehe)
    left(90)
    forward(breite)
    #forward(10)





























