from turtle import *
was = 100
ha = 100
pensize(10)
while True:
    speed(1000)
    forward(ha)
    left(was)
    color("black")
    forward(ha)
    right(was)
    color("darkblue")
    forward(ha)
    left(was)
    color("black")
    forward(ha)
    right(was)
    color("darkblue")
    forward(ha)
    right(was)
    color("black")
    forward(ha)
    ha = ha-0.1