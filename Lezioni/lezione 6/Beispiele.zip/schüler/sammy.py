from turtle import *
forward(100)
left(90)
forward(100)
left(30)
forward(100)
left(120)
forward(100)
left(30)
forward(100)
left(90)
forward(30)


done()