# ============================================================
#  ZAUN MIT SCHLEIFE
#
#  Acht Latten, und trotzdem nur sieben Zeilen für alle acht.
# ============================================================

from turtle import *

speed(11)
pensize(6)
color("saddlebrown")

# ===== EINSTELLUNGEN =====
latten = 8         # <-- wie viele Latten
abstand = 30       # <-- wie weit auseinander
hoehe = 90         # <-- wie hoch

# --- An den Start ---
penup()
goto(-150, -80)
pendown()
setheading(0)

# --- Die Latten ---
for i in range(latten):
    left(90)
    forward(hoehe)
    backward(hoehe)
    right(90)
    penup()
    forward(abstand)
    pendown()

# --- Die zwei Querlatten ---
penup()
goto(-150, -80 + hoehe * 0.3)
pendown()
setheading(0)
forward(abstand * (latten - 1))

penup()
goto(-150, -80 + hoehe * 0.7)
pendown()
forward(abstand * (latten - 1))

done()