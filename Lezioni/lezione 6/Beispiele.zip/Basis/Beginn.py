# ============================================================
#  HAUS MIT VARIABLEN
#
#  Oben stehen drei Zahlen. Alles andere rechnet sich daraus aus.
#  Ändere NUR die drei Zahlen oben und drück Play.
# ============================================================

from turtle import *

speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

groesse = 180      # <-- wie groß das Haus ist
start_x = 0      # <-- wo es steht: links / rechts
start_y = -300     # <-- wo es steht: unten / oben

# ============================================================

# --- An den Start ---
penup()
goto(start_x, start_y)
pendown()
setheading(0)