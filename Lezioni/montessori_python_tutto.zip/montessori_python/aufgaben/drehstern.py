# ============================================================
#  DREHSTERN — dieselbe Form, immer ein Stück weitergedreht
#
#  Gleiche Größe, nur gedreht: so entsteht ein Muster.
#  Probiere Stern (5 Ecken) und Quadrat (4 Ecken) aus.
# ============================================================

from turtle import *

speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen
pensize(1)

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

ecken = 5            # <-- 5 = Stern, 4 = Quadrat
winkel = 144         # <-- Stern: 144, Quadrat: 90
groesse = 180        # <-- Kantenlänge der Form
drehung = 2          # <-- um so viele Grad wird die Form jedes Mal gedreht (probiere 6)
anzahl = 180         # <-- 360 geteilt durch "drehung" = eine ganze Runde
farbe = "darkorange" # <-- Farbe der Linien
start_x = 0          # <-- wo der Drehpunkt (eine Ecke) steht: links / rechts
start_y = 0          # <-- wo der Drehpunkt (eine Ecke) steht: unten / oben

# ============================================================

color(farbe)

# --- An den Start ---
penup()
goto(start_x, start_y)
pendown()

# --- Form zeichnen und drehen ---
for nummer in range(anzahl):

    # Eine Form: "ecken" Linien, nach jeder Linie "winkel" Grad drehen.
    for linie in range(ecken):
        forward(groesse)
        right(winkel)

    # Die ganze Form ein kleines Stück weiterdrehen.
    right(drehung)

hideturtle()  # Pfeil ausblenden
done()
