# ============================================================
#  ROSETTE — Ein Quadrat, viele Male, jedes Mal gedreht
#
#  Die innere Schleife zeichnet ein Quadrat.
#  Die äußere Schleife wiederholt es und dreht dazwischen.
#  Ändere EINE Zahl und wette: Was passiert mit dem Bild?
# ============================================================

from turtle import *

setup(700, 700)   # Fenstergröße
speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen
pensize(2)

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

anzahl = 12          # <-- wie viele Quadrate
seite = 120          # <-- Länge einer Quadrat-Seite
farbe = "crimson"    # <-- Farbe, englisch und in Gänsefüßchen: "red", "blue"

# ============================================================

color(farbe)

for i in range(anzahl):
    for ecke in range(4):
        forward(seite)
        left(90)
    left(360 / anzahl)

hideturtle()  # Pfeil ausblenden
done()


# ============================================================
#  WETT-MISSIONEN
#  Erst wetten (▲ mehr, ▼ weniger, ＝ gleich), dann ändern
#  und ausführen (Run). Wer hat richtig gewettet?
#
#  1. anzahl = 6
#  2. anzahl = 36
#  3. seite = 60
#  4. seite = 200
#  5. anzahl = 1
#  6. range(3) und left(120) in der inneren Schleife
#     (ein Dreieck statt eines Quadrats)
# ============================================================
