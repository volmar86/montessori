# ============================================================
#  CHAOS-SPIEL — Aus Zufall wird ein Muster
#
#  Ein Punkt springt immer wieder ein Stück in Richtung einer
#  zufälligen Ecke und hinterlässt einen Fleck.
#  Reiner Zufall. Warte, bis du das Bild siehst ...
# ============================================================

from turtle import *
from random import randint

setup(700, 700)   # Fenstergröße
tracer(0)         # nicht jeden Punkt einzeln zeigen (viel schneller)
hideturtle()
penup()

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

anzahl = 5000        # <-- wie viele Punkte
sprung = 0.5         # <-- wie weit der Punkt springt: 0.5 = halber Weg zur Ecke
groesse = 2          # <-- Größe jedes Punktes
farbe = "navy"       # <-- Farbe, englisch und in Gänsefüßchen: "red", "blue"

# ============================================================

# Die drei Ecken des Dreiecks
ax = -300
ay = -260
bx = 300
by = -260
cx = 0
cy = 260

x = 0
y = 0
color(farbe)

for i in range(anzahl):
    ecke = randint(1, 3)
    if ecke == 1:
        zielx = ax
        ziely = ay
    elif ecke == 2:
        zielx = bx
        ziely = by
    else:
        zielx = cx
        ziely = cy
    x = x + (zielx - x) * sprung
    y = y + (ziely - y) * sprung
    goto(x, y)
    dot(groesse)

update()
done()


# ============================================================
#  MISSIONEN FÜR DICH
#  Erst wetten, dann ändern und ausführen (Run).
#
#  1. anzahl = 20000       (dauert länger: wie sieht es aus?)
#  2. sprung = 0.6
#  3. sprung = 0.4
#  4. Färbe jeden Punkt nach seiner Ecke: in jedem Zweig
#     der if-Kette ein eigenes color(...)
#  5. Baue eine vierte Ecke ein (ein Quadrat): randint(1, 4)
#     und ein weiterer elif-Zweig. Wette zuerst: Was entsteht?
#  6. Mit vier Ecken: sprung = 0.67. Was ist jetzt anders?
# ============================================================
