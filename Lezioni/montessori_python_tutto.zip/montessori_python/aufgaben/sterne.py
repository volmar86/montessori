# ============================================================
#  STERNENSPIRALE — Sterne, die wachsen und wandern
#
#  Ein Stern, immer wieder: ein bisschen größer und ein
#  bisschen weiter. Ändere die Zahlen und schau, was passiert.
# ============================================================

from turtle import *

speed(0)          # 0 = sofort, 1 = langsam zum Zuschauen
pensize(2)

# ============================================================
#  HIER WIRD ALLES EINGESTELLT
# ============================================================

anzahl = 12          # <-- wie viele Sterne
groesse = 15         # <-- Kantenlänge des ersten Sterns
wachstum = 5         # <-- so viel größer wird jeder neue Stern
drehung = 30         # <-- Abbiegen nach jedem Stern (0 = gerade Reihe)
farbe = "purple"     # <-- Farbe der Sterne
start_x = 90         # <-- wo der erste Stern steht: links / rechts
start_y = -15        # <-- wo der erste Stern steht: unten / oben

# ============================================================

color(farbe)

# --- An den Start ---
penup()
goto(start_x, start_y)
pendown()

# --- Sterne zeichnen ---
for nummer in range(anzahl):

    # Ein Stern: 5 Linien, nach jeder Linie 144 Grad drehen.
    # 5 mal 144 = 720 Grad = 2 volle Drehungen, darum schließt er sich.
    for linie in range(5):
        forward(groesse)
        right(144)

    # Zum nächsten Stern: ohne zu zeichnen weiterlaufen und abbiegen.
    penup()
    forward(groesse * 2)
    left(drehung)
    pendown()

    # Der nächste Stern wird etwas größer.
    groesse = groesse + wachstum

hideturtle()  # Pfeil ausblenden
done()
